const hour = document.querySelector('.h'),
    min = document.querySelector('.m'),
    sec = document.querySelector('.s'),
    minNumber = document.querySelector('.minutes'),
    hourNumber = document.querySelector('.hours');

function clock() {
    const time = new Date();
    let seconds = time.getSeconds();
    let minutes = time.getMinutes();
    let hours = time.getHours();

    sec.style = `transform: rotate(${seconds * 6}deg); transition:1s linear;`;
    min.style = `transform: rotate(${minutes * 6}deg); transition:1s linear;`;
    hour.style = `transform: rotate(${hours * 30}deg); transition:1s linear;`;

    minNumber.innerHTML = minutes < 10 ? '0' + minutes : minutes;
    hourNumber.innerHTML = hours < 10 ? '0' + hours : hours;

    setTimeout(() => clock(), 1000);
}
clock();

const links = document.querySelectorAll('.tabsItem'),
    contents = document.querySelectorAll('.tabsContentItem');

for (let i = 0; i < links.length; i++) {
    links[i].addEventListener('click', function () {
        for (let ix = 0; ix < links.length; ix++) {
            links[ix].classList.remove('active');
            contents[ix].classList.remove('active');
        }
        tabs(this, contents[i]);
    })

}

function tabs(link, content) {
    link.classList.add('active');
    content.classList.add('active');
}

// 

const watchBtn = document.querySelector('.stopwatch__btn'),
    secondWatch = document.querySelector('.stopwatch__seconds'),
    minutesWatch = document.querySelector('.stopwatch__minutes'),
    hoursWatch = document.querySelector('.stopwatch__hours'),
    secondInfo = document.querySelector('.tabsLink__span');

watchBtn.addEventListener('click', function () {

    if (this.innerHTML == 'start') {
        this.innerHTML = 'stop';
        let i = 0;
        secondInfo.classList.add('active');
        setTimeout(() => stopWatch(this, i), 1000);
        
    } else if (this.innerHTML == 'stop') {
        this.innerHTML = 'clear';
        secondInfo.classList.add('active_clear');
    }else {
        secondWatch.innerHTML = 0;
        minutesWatch.innerHTML = 0;
        hoursWatch.innerHTML = 0;
        this.innerHTML = 'start';
        secondInfo.classList.remove('active');
        secondInfo.classList.remove('active_clear');
    }
    setTheme(this);
});

function stopWatch(el, i) {
    if (el.innerHTML == 'stop') {
        if (i == 60) {
            i = 0;
            secondWatch.innerHTML = i;
            if (minutesWatch.innerHTML == 59) {
                minutesWatch.innerHTML = 0;
                hoursWatch.innerHTML++;
            } else {
                minutesWatch.innerHTML++;
            }
        } else {
            i++;
            secondWatch.innerHTML = i;
        }
        setTimeout(() => stopWatch(el, i), 1000);
    }
};
function setTheme(el) {
    el.style.color = 'blue';
    if (el.innerHTML == 'start') {
        el.style.background = 'green';
    }else if(el.innerHTML == 'stop'){
        el.style.background = 'red';
    }else if(el.innerHTML == 'clear'){
        el.style.background = 'yellow';
    }
};
setTheme(watchBtn);